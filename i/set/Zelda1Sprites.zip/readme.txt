This file came from The Legends of Zelda (http://loz.zeldalegends.net).
The sprites came from various web sites. You can go to my web site to figure out where they came from.